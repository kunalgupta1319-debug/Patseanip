import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { Home, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-[var(--cream-dark)] flex items-center justify-center py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center max-w-2xl"
      >
        <div className="mb-8">
          <h1 className="text-9xl font-heading font-bold bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] bg-clip-text text-transparent mb-4">
            404
          </h1>
          <h2 className="text-4xl font-heading font-semibold text-foreground mb-4">
            Page Not Found
          </h2>
          <p className="text-xl text-foreground/70 mb-8">
            Oops! The page you're looking for doesn't exist. It might have been moved or deleted.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/"
            className="px-8 py-4 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-xl hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all flex items-center justify-center gap-2 font-medium"
          >
            <Home className="w-5 h-5" />
            Go Home
          </Link>
          <button
            onClick={() => window.history.back()}
            className="px-8 py-4 bg-white border-2 border-[var(--gold)] text-foreground rounded-xl hover:bg-[var(--gold)]/5 transition-all flex items-center justify-center gap-2 font-medium"
          >
            <ArrowLeft className="w-5 h-5" />
            Go Back
          </button>
        </div>

        <div className="mt-12 p-6 bg-white rounded-2xl border-2 border-[var(--gold)]/20 inline-block">
          <p className="text-foreground/70 mb-4">Looking for something specific?</p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link to="/categories" className="text-[var(--gold)] hover:text-[var(--gold-dark)] transition-colors">
              Categories
            </Link>
            <span className="text-foreground/30">•</span>
            <Link to="/templates" className="text-[var(--gold)] hover:text-[var(--gold-dark)] transition-colors">
              Templates
            </Link>
            <span className="text-foreground/30">•</span>
            <Link to="/pricing" className="text-[var(--gold)] hover:text-[var(--gold-dark)] transition-colors">
              Pricing
            </Link>
            <span className="text-foreground/30">•</span>
            <Link to="/dashboard" className="text-[var(--gold)] hover:text-[var(--gold-dark)] transition-colors">
              Dashboard
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
