import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { Mail, Lock, User, Sparkles, Eye, EyeOff } from "lucide-react";

export default function Signup() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Will be connected to Supabase auth later
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[var(--cream)] via-[var(--gold-light)]/30 to-[var(--cream-dark)] flex items-center justify-center py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="bg-white rounded-2xl p-8 shadow-2xl border-2 border-[var(--gold)]/20">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-[var(--gold)] to-[var(--gold-dark)] rounded-xl flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-heading font-bold text-foreground mb-2">
              Create Account
            </h1>
            <p className="text-foreground/70">
              Start creating stunning invitations today
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block mb-2 flex items-center gap-2">
                <User className="w-4 h-4 text-[var(--gold)]" />
                Full Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 rounded-lg border-2 border-[var(--gold)]/20 focus:border-[var(--gold)] outline-none transition-colors bg-white"
                placeholder="John Doe"
                required
              />
            </div>

            <div>
              <label className="block mb-2 flex items-center gap-2">
                <Mail className="w-4 h-4 text-[var(--gold)]" />
                Email
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 rounded-lg border-2 border-[var(--gold)]/20 focus:border-[var(--gold)] outline-none transition-colors bg-white"
                placeholder="your.email@example.com"
                required
              />
            </div>

            <div>
              <label className="block mb-2 flex items-center gap-2">
                <Lock className="w-4 h-4 text-[var(--gold)]" />
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border-2 border-[var(--gold)]/20 focus:border-[var(--gold)] outline-none transition-colors bg-white pr-12"
                  placeholder="Create a strong password"
                  required
                  minLength={8}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-foreground/50 hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <p className="mt-2 text-xs text-foreground/60">Must be at least 8 characters</p>
            </div>

            <label className="flex items-start gap-2 text-sm">
              <input
                type="checkbox"
                className="w-4 h-4 accent-[var(--gold)] rounded mt-0.5"
                required
              />
              <span className="text-foreground/70">
                I agree to the{" "}
                <a href="#" className="text-[var(--gold)] hover:text-[var(--gold-dark)]">
                  Terms of Service
                </a>{" "}
                and{" "}
                <a href="#" className="text-[var(--gold)] hover:text-[var(--gold-dark)]">
                  Privacy Policy
                </a>
              </span>
            </label>

            <button
              type="submit"
              className="w-full px-6 py-4 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-xl hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all font-medium"
            >
              Create Account
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-foreground/70">
              Already have an account?{" "}
              <Link to="/login" className="text-[var(--gold)] hover:text-[var(--gold-dark)] font-medium transition-colors">
                Login
              </Link>
            </p>
          </div>

          <div className="mt-6 pt-6 border-t border-[var(--gold)]/20">
            <p className="text-center text-sm text-foreground/60 mb-4">Or sign up with</p>
            <div className="grid grid-cols-2 gap-3">
              <button className="px-4 py-3 border-2 border-[var(--gold)]/20 rounded-lg hover:border-[var(--gold)] transition-colors flex items-center justify-center gap-2">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Google
              </button>
              <button className="px-4 py-3 border-2 border-[var(--gold)]/20 rounded-lg hover:border-[var(--gold)] transition-colors flex items-center justify-center gap-2">
                <svg className="w-5 h-5" fill="#1877F2" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                Facebook
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
