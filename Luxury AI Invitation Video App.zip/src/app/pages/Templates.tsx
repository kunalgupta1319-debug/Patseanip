import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { motion } from "motion/react";
import { Play, Image as ImageIcon, Star, Filter } from "lucide-react";

export default function Templates() {
  const { category } = useParams();
  const [selectedType, setSelectedType] = useState<"all" | "video" | "image">("all");

  const templates = [
    {
      id: "1",
      name: "Royal Golden Wedding",
      category: "wedding",
      type: "video",
      thumbnail: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&q=80",
      rating: 4.9,
      uses: 1234,
      premium: false
    },
    {
      id: "2",
      name: "Floral Elegance",
      category: "wedding",
      type: "image",
      thumbnail: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=600&q=80",
      rating: 4.8,
      uses: 892,
      premium: true
    },
    {
      id: "3",
      name: "Traditional Haldi",
      category: "haldi",
      type: "video",
      thumbnail: "https://images.unsplash.com/photo-1583391733981-9c0b0c5b0de5?w=600&q=80",
      rating: 4.9,
      uses: 567,
      premium: false
    },
    {
      id: "4",
      name: "Mehendi Magic",
      category: "mehendi",
      type: "video",
      thumbnail: "https://images.unsplash.com/photo-1537633468767-e2f0c6a53ce3?w=600&q=80",
      rating: 5.0,
      uses: 734,
      premium: true
    },
    {
      id: "5",
      name: "Romantic Engagement",
      category: "engagement",
      type: "image",
      thumbnail: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=600&q=80",
      rating: 4.7,
      uses: 456,
      premium: false
    },
    {
      id: "6",
      name: "Birthday Celebration",
      category: "birthday",
      type: "video",
      thumbnail: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=600&q=80",
      rating: 4.8,
      uses: 923,
      premium: false
    },
    {
      id: "7",
      name: "Classic Anniversary",
      category: "anniversary",
      type: "image",
      thumbnail: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=600&q=80",
      rating: 4.9,
      uses: 345,
      premium: true
    },
    {
      id: "8",
      name: "Baby Shower Joy",
      category: "baby shower",
      type: "video",
      thumbnail: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=600&q=80",
      rating: 4.8,
      uses: 612,
      premium: false
    },
    {
      id: "9",
      name: "Luxury Palace Wedding",
      category: "wedding",
      type: "video",
      thumbnail: "https://images.unsplash.com/photo-1591604466107-ec97de577aff?w=600&q=80",
      rating: 5.0,
      uses: 1567,
      premium: true
    },
  ];

  const filteredTemplates = templates.filter(template => {
    const categoryMatch = !category || category === "all" || template.category === category;
    const typeMatch = selectedType === "all" || template.type === selectedType;
    return categoryMatch && typeMatch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-[var(--cream-dark)] py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-heading font-bold text-foreground mb-4"
          >
            {category ? `${category.charAt(0).toUpperCase() + category.slice(1)} Templates` : "All Templates"}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-foreground/70"
          >
            Browse our collection of premium invitation templates
          </motion.p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-8 items-center">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-[var(--gold)]" />
            <span className="font-medium">Filter:</span>
          </div>
          <button
            onClick={() => setSelectedType("all")}
            className={`px-6 py-2 rounded-lg transition-all ${
              selectedType === "all"
                ? "bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white"
                : "bg-white border-2 border-[var(--gold)]/20 hover:border-[var(--gold)]"
            }`}
          >
            All
          </button>
          <button
            onClick={() => setSelectedType("video")}
            className={`px-6 py-2 rounded-lg transition-all ${
              selectedType === "video"
                ? "bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white"
                : "bg-white border-2 border-[var(--gold)]/20 hover:border-[var(--gold)]"
            }`}
          >
            Video Invitations
          </button>
          <button
            onClick={() => setSelectedType("image")}
            className={`px-6 py-2 rounded-lg transition-all ${
              selectedType === "image"
                ? "bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white"
                : "bg-white border-2 border-[var(--gold)]/20 hover:border-[var(--gold)]"
            }`}
          >
            Image Cards
          </button>
        </div>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTemplates.map((template, index) => (
            <motion.div
              key={template.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link
                to={`/editor/${template.id}`}
                className="group block bg-white rounded-2xl overflow-hidden border-2 border-[var(--gold)]/20 hover:border-[var(--gold)] hover:shadow-2xl transition-all"
              >
                <div className="relative aspect-video overflow-hidden bg-[var(--cream-dark)]">
                  <img
                    src={template.thumbnail}
                    alt={template.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    {template.type === "video" ? (
                      <div className="w-16 h-16 rounded-full bg-white/90 flex items-center justify-center">
                        <Play className="w-8 h-8 text-[var(--gold)] ml-1" />
                      </div>
                    ) : (
                      <div className="w-16 h-16 rounded-full bg-white/90 flex items-center justify-center">
                        <ImageIcon className="w-8 h-8 text-[var(--gold)]" />
                      </div>
                    )}
                  </div>
                  {template.premium && (
                    <div className="absolute top-3 right-3 px-3 py-1 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white text-xs font-medium rounded-full">
                      Premium
                    </div>
                  )}
                </div>

                <div className="p-5">
                  <h3 className="text-xl font-heading font-semibold mb-2 text-foreground">
                    {template.name}
                  </h3>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-[var(--gold)] text-[var(--gold)]" />
                      <span className="font-medium">{template.rating}</span>
                    </div>
                    <span className="text-foreground/60">{template.uses.toLocaleString()} uses</span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {filteredTemplates.length === 0 && (
          <div className="text-center py-20">
            <p className="text-xl text-foreground/60">No templates found for the selected filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}
