import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";

export default function Categories() {
  const categories = [
    {
      name: "Wedding",
      icon: "💍",
      color: "from-rose-400 to-pink-500",
      description: "Traditional and modern wedding invitations",
      templates: 45,
      image: "https://images.unsplash.com/photo-1606800052052-a08af7148866?w=800&q=80"
    },
    {
      name: "Haldi",
      icon: "🌼",
      color: "from-yellow-400 to-orange-400",
      description: "Vibrant Haldi ceremony invitations",
      templates: 28,
      image: "https://images.unsplash.com/photo-1583391733981-9c0b0c5b0de5?w=800&q=80"
    },
    {
      name: "Mehendi",
      icon: "🎨",
      color: "from-green-400 to-emerald-500",
      description: "Beautiful Mehendi night invites",
      templates: 32,
      image: "https://images.unsplash.com/photo-1537633468767-e2f0c6a53ce3?w=800&q=80"
    },
    {
      name: "Engagement",
      icon: "💝",
      color: "from-purple-400 to-pink-500",
      description: "Elegant engagement ceremony cards",
      templates: 38,
      image: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&q=80"
    },
    {
      name: "Birthday",
      icon: "🎂",
      color: "from-blue-400 to-indigo-500",
      description: "Fun and festive birthday invitations",
      templates: 52,
      image: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=800&q=80"
    },
    {
      name: "Anniversary",
      icon: "❤️",
      color: "from-red-400 to-rose-500",
      description: "Romantic anniversary celebration cards",
      templates: 24,
      image: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=800&q=80"
    },
    {
      name: "Baby Shower",
      icon: "👶",
      color: "from-teal-400 to-cyan-500",
      description: "Adorable baby shower invitations",
      templates: 30,
      image: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=800&q=80"
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-[var(--cream-dark)] py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-heading font-bold text-foreground mb-4"
          >
            Choose Your Category
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-foreground/70 max-w-2xl mx-auto"
          >
            Select the perfect category for your special occasion
          </motion.p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link
                to={`/templates/${category.name.toLowerCase()}`}
                className="group block bg-white rounded-2xl overflow-hidden border-2 border-[var(--gold)]/20 hover:border-[var(--gold)] hover:shadow-2xl transition-all"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${category.color} opacity-60`}></div>
                  <div className="absolute top-4 left-4 w-16 h-16 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center text-4xl">
                    {category.icon}
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-2xl font-heading font-semibold mb-2 text-foreground">
                    {category.name}
                  </h3>
                  <p className="text-foreground/70 mb-4">{category.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground/60">
                      {category.templates} Templates
                    </span>
                    <div className="flex items-center gap-2 text-[var(--gold)] font-medium group-hover:gap-3 transition-all">
                      Browse
                      <ArrowRight className="w-5 h-5" />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
