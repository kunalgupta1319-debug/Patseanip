import { Link } from "react-router-dom";
import { Sparkles, Video, Image, Music, Share2, Download, Star, TrendingUp, Clock } from "lucide-react";
import { motion } from "motion/react";

export default function Home() {
  const categories = [
    { name: "Wedding", icon: "💍", color: "from-rose-400 to-pink-500" },
    { name: "Haldi", icon: "🌼", color: "from-yellow-400 to-orange-400" },
    { name: "Mehendi", icon: "🎨", color: "from-green-400 to-emerald-500" },
    { name: "Engagement", icon: "💝", color: "from-purple-400 to-pink-500" },
    { name: "Birthday", icon: "🎂", color: "from-blue-400 to-indigo-500" },
    { name: "Anniversary", icon: "❤️", color: "from-red-400 to-rose-500" },
    { name: "Baby Shower", icon: "👶", color: "from-teal-400 to-cyan-500" },
  ];

  const features = [
    { icon: Video, title: "AI Video Generation", desc: "Create stunning invitation videos automatically" },
    { icon: Image, title: "Image Cards", desc: "Beautiful image invitations with your photos" },
    { icon: Music, title: "Music Library", desc: "Choose from curated Indian wedding music" },
    { icon: Share2, title: "WhatsApp Share", desc: "Share directly with your guests" },
    { icon: Download, title: "HD Downloads", desc: "Download in high quality formats" },
    { icon: Star, title: "Premium Templates", desc: "Luxury designs for every occasion" },
  ];

  const testimonials = [
    { name: "Priya & Rahul", text: "Our wedding invites were absolutely stunning! Everyone loved them.", rating: 5 },
    { name: "Anjali Sharma", text: "So easy to use and the results are professional. Highly recommend!", rating: 5 },
    { name: "Vikram & Neha", text: "Saved us so much time and money. The AI did an amazing job!", rating: 5 },
  ];

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[var(--cream)] via-[var(--gold-light)]/30 to-[var(--cream-dark)] py-20 sm:py-32">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyMTIsIDE3NSwgNTUsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-40"></div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-4xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/60 backdrop-blur-sm rounded-full border border-[var(--gold)]/30 mb-6">
              <Sparkles className="w-4 h-4 text-[var(--gold)]" />
              <span className="text-sm text-foreground/70">AI-Powered Invitation Creator</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-heading font-bold text-foreground mb-6 leading-tight">
              Create <span className="bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] bg-clip-text text-transparent">Luxury</span> Invitations in Minutes
            </h1>

            <p className="text-xl text-foreground/70 mb-10 max-w-2xl mx-auto">
              AI-generated invitation videos and cards for Indian weddings and celebrations. Premium designs, instant creation, perfect memories.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link
                to="/categories"
                className="px-8 py-4 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-xl hover:shadow-2xl hover:shadow-[var(--gold)]/40 transition-all text-lg font-medium flex items-center gap-2 w-full sm:w-auto justify-center"
              >
                <Sparkles className="w-5 h-5" />
                Start Creating Free
              </Link>
              <Link
                to="/templates"
                className="px-8 py-4 bg-white text-foreground rounded-xl border-2 border-[var(--gold)] hover:bg-[var(--gold)]/5 transition-all text-lg font-medium w-full sm:w-auto justify-center flex items-center gap-2"
              >
                Browse Templates
              </Link>
            </div>

            <div className="mt-12 flex flex-wrap justify-center gap-8 text-sm text-foreground/60">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-[var(--gold)]" />
                <span>10,000+ Invitations Created</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-[var(--gold)]" />
                <span>Created in Under 5 Minutes</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-[var(--gold)]" />
                <span>4.9/5 Rating</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-heading font-bold text-foreground mb-4">
              Perfect for Every Celebration
            </h2>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              Choose from our curated categories designed for Indian weddings and special occasions
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-4">
            {categories.map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link
                  to={`/templates/${category.name.toLowerCase()}`}
                  className="group block p-6 bg-white rounded-2xl border-2 border-[var(--gold)]/20 hover:border-[var(--gold)] hover:shadow-xl transition-all text-center"
                >
                  <div className={`w-16 h-16 mx-auto mb-3 rounded-full bg-gradient-to-br ${category.color} flex items-center justify-center text-3xl group-hover:scale-110 transition-transform`}>
                    {category.icon}
                  </div>
                  <h3 className="font-medium text-foreground">{category.name}</h3>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-b from-background to-[var(--cream-dark)]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-heading font-bold text-foreground mb-4">
              Everything You Need
            </h2>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              Powerful features to create stunning invitations effortlessly
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-8 bg-white rounded-2xl border border-[var(--gold)]/20 hover:border-[var(--gold)] hover:shadow-xl transition-all"
              >
                <div className="w-14 h-14 mb-4 rounded-xl bg-gradient-to-br from-[var(--gold)] to-[var(--gold-dark)] flex items-center justify-center">
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-heading font-semibold mb-2">{feature.title}</h3>
                <p className="text-foreground/70">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-heading font-bold text-foreground mb-4">
              Loved by Thousands
            </h2>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              See what our happy customers have to say
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-8 bg-white rounded-2xl border border-[var(--gold)]/20"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[var(--gold)] text-[var(--gold)]" />
                  ))}
                </div>
                <p className="text-foreground/80 mb-4 italic">"{testimonial.text}"</p>
                <p className="font-medium text-foreground">- {testimonial.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-[var(--gold)] to-[var(--gold-dark)] relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-40"></div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto text-white">
            <h2 className="text-4xl sm:text-5xl font-heading font-bold mb-6">
              Ready to Create Your Perfect Invitation?
            </h2>
            <p className="text-xl mb-10 text-white/90">
              Join thousands of happy customers. Start creating beautiful invitations today.
            </p>
            <Link
              to="/signup"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-[var(--gold-dark)] rounded-xl hover:shadow-2xl hover:scale-105 transition-all text-lg font-medium"
            >
              <Sparkles className="w-5 h-5" />
              Get Started - It's Free
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
