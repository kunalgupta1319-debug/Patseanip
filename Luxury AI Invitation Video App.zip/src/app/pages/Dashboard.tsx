import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { Plus, Video, Image as ImageIcon, Calendar, Download, Share2, Trash2, Edit } from "lucide-react";

export default function Dashboard() {
  const userInvitations = [
    {
      id: "1",
      name: "Priya & Rahul's Wedding",
      category: "Wedding",
      type: "video",
      thumbnail: "https://images.unsplash.com/photo-1519741497674-611481863552?w=400&q=80",
      createdAt: "2026-05-08",
      status: "completed",
    },
    {
      id: "2",
      name: "Haldi Ceremony",
      category: "Haldi",
      type: "image",
      thumbnail: "https://images.unsplash.com/photo-1583391733981-9c0b0c5b0de5?w=400&q=80",
      createdAt: "2026-05-10",
      status: "draft",
    },
    {
      id: "3",
      name: "Engagement Celebration",
      category: "Engagement",
      type: "video",
      thumbnail: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=400&q=80",
      createdAt: "2026-05-09",
      status: "completed",
    },
  ];

  const stats = [
    { label: "Total Invitations", value: "12", icon: Video },
    { label: "Shared", value: "8", icon: Share2 },
    { label: "Downloads", value: "24", icon: Download },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-[var(--cream-dark)] py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
        >
          <div>
            <h1 className="text-5xl font-heading font-bold text-foreground mb-2">
              My Dashboard
            </h1>
            <p className="text-xl text-foreground/70">
              Manage your invitations and track your creations
            </p>
          </div>
          <Link
            to="/categories"
            className="px-6 py-3 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-xl hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all flex items-center gap-2 font-medium"
          >
            <Plus className="w-5 h-5" />
            Create New
          </Link>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 border-2 border-[var(--gold)]/20"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-foreground/70 mb-1">{stat.label}</p>
                  <p className="text-4xl font-heading font-bold text-foreground">{stat.value}</p>
                </div>
                <div className="w-14 h-14 bg-gradient-to-br from-[var(--gold)] to-[var(--gold-dark)] rounded-xl flex items-center justify-center">
                  <stat.icon className="w-7 h-7 text-white" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Invitations */}
        <div>
          <h2 className="text-3xl font-heading font-semibold mb-6">Your Invitations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {userInvitations.map((invitation, index) => (
              <motion.div
                key={invitation.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="bg-white rounded-2xl overflow-hidden border-2 border-[var(--gold)]/20 hover:border-[var(--gold)] hover:shadow-xl transition-all group"
              >
                <div className="relative h-48 overflow-hidden bg-[var(--cream-dark)]">
                  <img
                    src={invitation.thumbnail}
                    alt={invitation.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-3 right-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      invitation.status === "completed"
                        ? "bg-green-500 text-white"
                        : "bg-yellow-500 text-white"
                    }`}>
                      {invitation.status === "completed" ? "Completed" : "Draft"}
                    </span>
                  </div>
                  <div className="absolute top-3 left-3">
                    {invitation.type === "video" ? (
                      <div className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center">
                        <Video className="w-5 h-5 text-[var(--gold)]" />
                      </div>
                    ) : (
                      <div className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center">
                        <ImageIcon className="w-5 h-5 text-[var(--gold)]" />
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-5">
                  <h3 className="text-xl font-heading font-semibold mb-2 text-foreground">
                    {invitation.name}
                  </h3>
                  <div className="flex items-center gap-2 text-sm text-foreground/60 mb-4">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(invitation.createdAt).toLocaleDateString('en-IN', { dateStyle: 'medium' })}</span>
                  </div>

                  <div className="flex gap-2">
                    <Link
                      to={`/editor/${invitation.id}`}
                      className="flex-1 px-4 py-2 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-lg hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all flex items-center justify-center gap-2 text-sm font-medium"
                    >
                      <Edit className="w-4 h-4" />
                      Edit
                    </Link>
                    <Link
                      to={`/preview/${invitation.id}`}
                      className="flex-1 px-4 py-2 bg-white border-2 border-[var(--gold)] text-foreground rounded-lg hover:bg-[var(--gold)]/5 transition-all flex items-center justify-center gap-2 text-sm font-medium"
                    >
                      <Download className="w-4 h-4" />
                      Download
                    </Link>
                    <button className="px-4 py-2 bg-white border-2 border-red-200 text-red-500 rounded-lg hover:bg-red-50 transition-all">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {userInvitations.length === 0 && (
            <div className="text-center py-20 bg-white rounded-2xl border-2 border-[var(--gold)]/20">
              <Video className="w-20 h-20 text-[var(--gold)]/30 mx-auto mb-4" />
              <h3 className="text-2xl font-heading font-semibold mb-2">No invitations yet</h3>
              <p className="text-foreground/70 mb-6">Create your first invitation to get started</p>
              <Link
                to="/categories"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-xl hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all font-medium"
              >
                <Plus className="w-5 h-5" />
                Create Invitation
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
