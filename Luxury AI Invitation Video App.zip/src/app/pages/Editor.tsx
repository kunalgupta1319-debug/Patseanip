import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Upload, Music, Eye, Download, Share2, Calendar, Clock, MapPin, User, Heart } from "lucide-react";
import { motion } from "motion/react";

export default function Editor() {
  const { templateId } = useParams();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    brideName: "",
    groomName: "",
    eventDate: "",
    eventTime: "",
    venue: "",
    message: "",
  });

  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);
  const [selectedMusic, setSelectedMusic] = useState("");

  const musicOptions = [
    { id: "1", name: "Tum Hi Ho - Romantic", duration: "4:22" },
    { id: "2", name: "Badtameez Dil - Upbeat", duration: "3:56" },
    { id: "3", name: "Tujh Mein Rab Dikhta Hai - Soulful", duration: "5:38" },
    { id: "4", name: "Mehendi Hai Rachne Waali - Traditional", duration: "4:15" },
    { id: "5", name: "London Thumakda - Celebration", duration: "3:42" },
  ];

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const urls = Array.from(files).map(file => URL.createObjectURL(file));
      setUploadedPhotos([...uploadedPhotos, ...urls]);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handlePreview = () => {
    navigate(`/preview/temp-${Date.now()}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-[var(--cream-dark)] py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-5xl font-heading font-bold text-foreground mb-2">
            Create Your Invitation
          </h1>
          <p className="text-xl text-foreground/70">
            Fill in the details to generate your AI-powered invitation
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Form Section */}
          <div className="space-y-6">
            {/* Photo Upload */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-2xl p-6 border-2 border-[var(--gold)]/20"
            >
              <h2 className="text-2xl font-heading font-semibold mb-4 flex items-center gap-2">
                <Upload className="w-6 h-6 text-[var(--gold)]" />
                Upload Photos
              </h2>
              <div className="space-y-4">
                <label className="block">
                  <div className="border-2 border-dashed border-[var(--gold)]/40 rounded-xl p-8 text-center hover:border-[var(--gold)] transition-colors cursor-pointer bg-[var(--cream-dark)]/30">
                    <Upload className="w-12 h-12 text-[var(--gold)] mx-auto mb-3" />
                    <p className="text-foreground/70 mb-2">Click to upload photos</p>
                    <p className="text-sm text-foreground/50">PNG, JPG up to 10MB</p>
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </div>
                </label>
                {uploadedPhotos.length > 0 && (
                  <div className="grid grid-cols-3 gap-3">
                    {uploadedPhotos.map((photo, index) => (
                      <div key={index} className="relative aspect-square rounded-lg overflow-hidden border-2 border-[var(--gold)]/20">
                        <img src={photo} alt={`Upload ${index + 1}`} className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>

            {/* Event Details */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-2xl p-6 border-2 border-[var(--gold)]/20"
            >
              <h2 className="text-2xl font-heading font-semibold mb-4 flex items-center gap-2">
                <Heart className="w-6 h-6 text-[var(--gold)]" />
                Event Details
              </h2>
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block mb-2 flex items-center gap-2">
                      <User className="w-4 h-4 text-[var(--gold)]" />
                      Bride's Name
                    </label>
                    <input
                      type="text"
                      name="brideName"
                      value={formData.brideName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-lg border-2 border-[var(--gold)]/20 focus:border-[var(--gold)] outline-none transition-colors bg-white"
                      placeholder="Enter bride's name"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 flex items-center gap-2">
                      <User className="w-4 h-4 text-[var(--gold)]" />
                      Groom's Name
                    </label>
                    <input
                      type="text"
                      name="groomName"
                      value={formData.groomName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-lg border-2 border-[var(--gold)]/20 focus:border-[var(--gold)] outline-none transition-colors bg-white"
                      placeholder="Enter groom's name"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block mb-2 flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-[var(--gold)]" />
                      Event Date
                    </label>
                    <input
                      type="date"
                      name="eventDate"
                      value={formData.eventDate}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-lg border-2 border-[var(--gold)]/20 focus:border-[var(--gold)] outline-none transition-colors bg-white"
                    />
                  </div>
                  <div>
                    <label className="block mb-2 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-[var(--gold)]" />
                      Event Time
                    </label>
                    <input
                      type="time"
                      name="eventTime"
                      value={formData.eventTime}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-lg border-2 border-[var(--gold)]/20 focus:border-[var(--gold)] outline-none transition-colors bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block mb-2 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[var(--gold)]" />
                    Venue
                  </label>
                  <input
                    type="text"
                    name="venue"
                    value={formData.venue}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border-2 border-[var(--gold)]/20 focus:border-[var(--gold)] outline-none transition-colors bg-white"
                    placeholder="Enter venue address"
                  />
                </div>

                <div>
                  <label className="block mb-2">
                    Special Message
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg border-2 border-[var(--gold)]/20 focus:border-[var(--gold)] outline-none transition-colors bg-white resize-none"
                    placeholder="Add a special message for your guests..."
                  />
                </div>
              </div>
            </motion.div>

            {/* Music Selection */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-2xl p-6 border-2 border-[var(--gold)]/20"
            >
              <h2 className="text-2xl font-heading font-semibold mb-4 flex items-center gap-2">
                <Music className="w-6 h-6 text-[var(--gold)]" />
                Select Music
              </h2>
              <div className="space-y-3">
                {musicOptions.map((music) => (
                  <label
                    key={music.id}
                    className={`flex items-center justify-between p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedMusic === music.id
                        ? "border-[var(--gold)] bg-[var(--gold)]/5"
                        : "border-[var(--gold)]/20 hover:border-[var(--gold)]/50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="music"
                        value={music.id}
                        checked={selectedMusic === music.id}
                        onChange={(e) => setSelectedMusic(e.target.value)}
                        className="w-5 h-5 accent-[var(--gold)]"
                      />
                      <div>
                        <p className="font-medium">{music.name}</p>
                        <p className="text-sm text-foreground/60">{music.duration}</p>
                      </div>
                    </div>
                    <Music className="w-5 h-5 text-[var(--gold)]" />
                  </label>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Preview Section */}
          <div className="lg:sticky lg:top-24 h-fit">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-2xl p-6 border-2 border-[var(--gold)]/20"
            >
              <h2 className="text-2xl font-heading font-semibold mb-4">Preview</h2>
              <div className="aspect-video bg-gradient-to-br from-[var(--cream-dark)] to-[var(--gold-light)] rounded-xl mb-6 flex items-center justify-center border-2 border-[var(--gold)]/20">
                {uploadedPhotos.length > 0 ? (
                  <img
                    src={uploadedPhotos[0]}
                    alt="Preview"
                    className="w-full h-full object-cover rounded-xl"
                  />
                ) : (
                  <div className="text-center">
                    <Eye className="w-16 h-16 text-[var(--gold)]/50 mx-auto mb-3" />
                    <p className="text-foreground/50">Preview will appear here</p>
                  </div>
                )}
              </div>

              {formData.brideName && formData.groomName && (
                <div className="text-center mb-6 p-4 bg-[var(--cream-dark)] rounded-lg">
                  <p className="font-heading text-3xl text-foreground mb-2">
                    {formData.brideName} & {formData.groomName}
                  </p>
                  {formData.eventDate && (
                    <p className="text-foreground/70">{new Date(formData.eventDate).toLocaleDateString('en-IN', { dateStyle: 'long' })}</p>
                  )}
                  {formData.venue && (
                    <p className="text-foreground/70 mt-1">{formData.venue}</p>
                  )}
                </div>
              )}

              <div className="space-y-3">
                <button
                  onClick={handlePreview}
                  className="w-full px-6 py-4 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-xl hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all flex items-center justify-center gap-2 font-medium"
                >
                  <Eye className="w-5 h-5" />
                  Generate Preview
                </button>
                <button
                  className="w-full px-6 py-4 bg-white border-2 border-[var(--gold)] text-foreground rounded-xl hover:bg-[var(--gold)]/5 transition-all flex items-center justify-center gap-2 font-medium"
                >
                  <Download className="w-5 h-5" />
                  Download
                </button>
                <button
                  className="w-full px-6 py-4 bg-[#25D366] text-white rounded-xl hover:bg-[#20BA5A] transition-all flex items-center justify-center gap-2 font-medium"
                >
                  <Share2 className="w-5 h-5" />
                  Share on WhatsApp
                </button>
              </div>

              <div className="mt-6 p-4 bg-[var(--gold-light)]/30 rounded-lg border border-[var(--gold)]/20">
                <p className="text-sm text-foreground/70 text-center">
                  💎 Upgrade to Premium for HD downloads and watermark-free videos
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
