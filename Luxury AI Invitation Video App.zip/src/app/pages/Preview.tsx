import { useParams, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { Download, Share2, Edit, Play, ArrowLeft } from "lucide-react";

export default function Preview() {
  const { invitationId } = useParams();
  const navigate = useNavigate();

  const invitation = {
    id: invitationId,
    name: "Priya & Rahul's Wedding",
    type: "video",
    thumbnail: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1200&q=80",
    brideName: "Priya",
    groomName: "Rahul",
    eventDate: "2026-06-15",
    eventTime: "18:00",
    venue: "The Grand Palace, Mumbai",
    message: "Join us in celebrating our special day filled with love, laughter, and happily ever after!",
  };

  const handleDownload = () => {
    navigate(`/download/${invitationId}`);
  };

  const handleWhatsAppShare = () => {
    const text = `You're invited to ${invitation.brideName} & ${invitation.groomName}'s Wedding!\nDate: ${new Date(invitation.eventDate).toLocaleDateString('en-IN', { dateStyle: 'long' })}\nVenue: ${invitation.venue}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-[var(--cream-dark)] py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate(-1)}
          className="mb-6 flex items-center gap-2 text-foreground/70 hover:text-[var(--gold)] transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </motion.button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Preview Section */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl overflow-hidden border-2 border-[var(--gold)]/20 shadow-xl"
            >
              <div className="relative aspect-video bg-gradient-to-br from-[var(--cream-dark)] to-[var(--gold-light)]">
                <img
                  src={invitation.thumbnail}
                  alt={invitation.name}
                  className="w-full h-full object-cover"
                />
                {invitation.type === "video" && (
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center group cursor-pointer">
                    <div className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Play className="w-10 h-10 text-[var(--gold)] ml-2" />
                    </div>
                  </div>
                )}
              </div>

              <div className="p-8">
                <div className="text-center mb-8 space-y-4">
                  <div className="inline-block px-6 py-2 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-full text-sm font-medium mb-4">
                    You're Invited
                  </div>

                  <h1 className="text-5xl font-heading font-bold text-foreground">
                    {invitation.brideName} <span className="text-[var(--gold)]">&</span> {invitation.groomName}
                  </h1>

                  <div className="flex items-center justify-center gap-8 text-foreground/70 flex-wrap">
                    <div className="text-center">
                      <p className="text-sm uppercase tracking-wider mb-1">Date</p>
                      <p className="text-lg font-medium">
                        {new Date(invitation.eventDate).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric'
                        })}
                      </p>
                    </div>
                    <div className="w-px h-12 bg-[var(--gold)]/30"></div>
                    <div className="text-center">
                      <p className="text-sm uppercase tracking-wider mb-1">Time</p>
                      <p className="text-lg font-medium">
                        {new Date(`2000-01-01T${invitation.eventTime}`).toLocaleTimeString('en-IN', {
                          hour: 'numeric',
                          minute: '2-digit',
                          hour12: true
                        })}
                      </p>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-[var(--gold)]/20">
                    <p className="text-sm uppercase tracking-wider text-foreground/60 mb-2">Venue</p>
                    <p className="text-xl font-medium text-foreground">{invitation.venue}</p>
                  </div>

                  {invitation.message && (
                    <div className="pt-6 border-t border-[var(--gold)]/20">
                      <p className="text-lg text-foreground/80 italic leading-relaxed">
                        "{invitation.message}"
                      </p>
                    </div>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t border-[var(--gold)]/20">
                  <button
                    onClick={handleDownload}
                    className="flex-1 px-6 py-4 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-xl hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all flex items-center justify-center gap-2 font-medium"
                  >
                    <Download className="w-5 h-5" />
                    Download
                  </button>
                  <button
                    onClick={handleWhatsAppShare}
                    className="flex-1 px-6 py-4 bg-[#25D366] text-white rounded-xl hover:bg-[#20BA5A] transition-all flex items-center justify-center gap-2 font-medium"
                  >
                    <Share2 className="w-5 h-5" />
                    Share on WhatsApp
                  </button>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-2xl p-6 border-2 border-[var(--gold)]/20"
            >
              <h2 className="text-2xl font-heading font-semibold mb-4">Actions</h2>
              <div className="space-y-3">
                <button
                  onClick={() => navigate(`/editor/${invitationId}`)}
                  className="w-full px-6 py-3 bg-white border-2 border-[var(--gold)] text-foreground rounded-xl hover:bg-[var(--gold)]/5 transition-all flex items-center justify-center gap-2 font-medium"
                >
                  <Edit className="w-5 h-5" />
                  Edit Invitation
                </button>
                <button className="w-full px-6 py-3 bg-white border-2 border-[var(--gold)]/20 text-foreground rounded-xl hover:border-[var(--gold)] transition-all flex items-center justify-center gap-2 font-medium">
                  <Share2 className="w-5 h-5" />
                  Copy Link
                </button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-gradient-to-br from-[var(--gold)] to-[var(--gold-dark)] rounded-2xl p-6 text-white"
            >
              <h3 className="text-xl font-heading font-semibold mb-3">Upgrade to Premium</h3>
              <p className="text-white/90 mb-4 text-sm">
                Remove watermark, download in 4K, and access premium templates
              </p>
              <button
                onClick={() => navigate('/pricing')}
                className="w-full px-6 py-3 bg-white text-[var(--gold-dark)] rounded-xl hover:shadow-lg transition-all font-medium"
              >
                View Plans
              </button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-2xl p-6 border-2 border-[var(--gold)]/20"
            >
              <h3 className="text-xl font-heading font-semibold mb-3">Need Help?</h3>
              <p className="text-foreground/70 mb-4 text-sm">
                Contact our support team for any questions or assistance
              </p>
              <a
                href="mailto:support@shaadicards.com"
                className="text-[var(--gold)] hover:text-[var(--gold-dark)] font-medium text-sm"
              >
                support@shaadicards.com
              </a>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
