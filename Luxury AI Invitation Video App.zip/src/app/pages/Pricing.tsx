import { motion } from "motion/react";
import { Check, Sparkles, Crown, Zap } from "lucide-react";
import { Link } from "react-router-dom";

export default function Pricing() {
  const plans = [
    {
      name: "Free",
      price: "₹0",
      period: "forever",
      description: "Perfect for trying out",
      icon: Sparkles,
      color: "from-gray-400 to-gray-500",
      features: [
        "3 invitations per month",
        "Basic templates",
        "Standard quality (720p)",
        "Watermark included",
        "Email support",
      ],
      limitations: [
        "HD downloads",
        "Premium templates",
        "Remove watermark",
        "Priority support",
      ],
    },
    {
      name: "Basic",
      price: "₹49",
      period: "per invitation",
      description: "Most popular choice",
      icon: Zap,
      color: "from-[var(--gold)] to-[var(--gold-dark)]",
      popular: true,
      features: [
        "Unlimited invitations",
        "All templates included",
        "HD quality (1080p)",
        "No watermark",
        "WhatsApp sharing",
        "Download in multiple formats",
        "Priority email support",
        "Commercial use allowed",
      ],
      limitations: [],
    },
    {
      name: "Premium",
      price: "₹999",
      period: "per year",
      description: "Best value for frequent users",
      icon: Crown,
      color: "from-purple-500 to-pink-500",
      features: [
        "Everything in Basic",
        "Unlimited invitations",
        "4K quality downloads",
        "Premium music library",
        "Custom branding",
        "Advanced templates",
        "24/7 priority support",
        "Early access to new features",
        "Bulk download",
      ],
      limitations: [],
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-[var(--cream-dark)] py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl sm:text-6xl font-heading font-bold text-foreground mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
            Choose the perfect plan for your needs. No hidden fees, cancel anytime.
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto mb-16">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`relative bg-white rounded-2xl p-8 border-2 ${
                plan.popular
                  ? "border-[var(--gold)] shadow-2xl shadow-[var(--gold)]/20 scale-105"
                  : "border-[var(--gold)]/20"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-6 py-2 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-full text-sm font-medium">
                  Most Popular
                </div>
              )}

              <div className={`w-14 h-14 bg-gradient-to-br ${plan.color} rounded-xl flex items-center justify-center mb-4`}>
                <plan.icon className="w-7 h-7 text-white" />
              </div>

              <h3 className="text-2xl font-heading font-bold text-foreground mb-2">
                {plan.name}
              </h3>
              <p className="text-foreground/70 mb-6">{plan.description}</p>

              <div className="mb-6">
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-heading font-bold text-foreground">{plan.price}</span>
                  <span className="text-foreground/60">/{plan.period}</span>
                </div>
              </div>

              <Link
                to={plan.name === "Free" ? "/signup" : "/signup"}
                className={`block w-full text-center px-6 py-4 rounded-xl font-medium transition-all mb-8 ${
                  plan.popular
                    ? "bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white hover:shadow-lg hover:shadow-[var(--gold)]/30"
                    : "bg-[var(--gold)]/10 text-[var(--gold-dark)] hover:bg-[var(--gold)]/20 border-2 border-[var(--gold)]/20"
                }`}
              >
                {plan.name === "Free" ? "Get Started" : "Choose Plan"}
              </Link>

              <div className="space-y-3">
                <p className="font-medium text-foreground mb-3">Includes:</p>
                {plan.features.map((feature) => (
                  <div key={feature} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-foreground/70">{feature}</span>
                  </div>
                ))}
                {plan.limitations.length > 0 && (
                  <>
                    <p className="font-medium text-foreground/50 mt-6 mb-3">Not included:</p>
                    {plan.limitations.map((limitation) => (
                      <div key={limitation} className="flex items-start gap-3">
                        <div className="w-5 h-5 flex-shrink-0 mt-0.5">
                          <div className="w-5 h-0.5 bg-foreground/20"></div>
                        </div>
                        <span className="text-foreground/40">{limitation}</span>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        {/* FAQ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="max-w-3xl mx-auto"
        >
          <h2 className="text-3xl font-heading font-bold text-center mb-8">
            Frequently Asked Questions
          </h2>
          <div className="space-y-4">
            {[
              {
                q: "Can I change my plan later?",
                a: "Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately.",
              },
              {
                q: "What payment methods do you accept?",
                a: "We accept all major credit/debit cards, UPI, net banking, and digital wallets.",
              },
              {
                q: "Is there a refund policy?",
                a: "Yes, we offer a 7-day money-back guarantee if you're not satisfied with our service.",
              },
              {
                q: "Can I use the invitations commercially?",
                a: "Basic and Premium plans include commercial use rights for all invitations you create.",
              },
            ].map((faq, index) => (
              <div key={index} className="bg-white rounded-xl p-6 border-2 border-[var(--gold)]/20">
                <h3 className="font-heading text-xl font-semibold mb-2 text-foreground">
                  {faq.q}
                </h3>
                <p className="text-foreground/70">{faq.a}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
