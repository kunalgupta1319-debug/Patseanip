import { useParams, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { Download as DownloadIcon, Video, Image as ImageIcon, FileVideo, FileImage, ArrowLeft, Check } from "lucide-react";
import { useState } from "react";

export default function Download() {
  const { invitationId } = useParams();
  const navigate = useNavigate();
  const [selectedFormat, setSelectedFormat] = useState("mp4");

  const formats = [
    { id: "mp4", name: "MP4 Video", ext: ".mp4", size: "25 MB", quality: "1080p", icon: FileVideo },
    { id: "mov", name: "MOV Video", ext: ".mov", size: "30 MB", quality: "1080p", icon: FileVideo, premium: true },
    { id: "jpg", name: "JPG Image", ext: ".jpg", size: "2 MB", quality: "High", icon: FileImage },
    { id: "png", name: "PNG Image", ext: ".png", size: "4 MB", quality: "High", icon: FileImage },
    { id: "4k", name: "4K Video", ext: ".mp4", size: "100 MB", quality: "4K UHD", icon: Video, premium: true },
  ];

  const handleDownload = () => {
    alert(`Downloading ${formats.find(f => f.id === selectedFormat)?.name}...`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-[var(--cream-dark)] py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        {/* Back Button */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate(-1)}
          className="mb-6 flex items-center gap-2 text-foreground/70 hover:text-[var(--gold)] transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Preview
        </motion.button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-5xl font-heading font-bold text-foreground mb-2">
            Download Your Invitation
          </h1>
          <p className="text-xl text-foreground/70">
            Choose your preferred format and quality
          </p>
        </motion.div>

        {/* Format Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl p-8 border-2 border-[var(--gold)]/20 mb-6"
        >
          <h2 className="text-2xl font-heading font-semibold mb-6">Select Format</h2>
          <div className="space-y-3">
            {formats.map((format) => (
              <label
                key={format.id}
                className={`flex items-center justify-between p-5 rounded-xl border-2 cursor-pointer transition-all ${
                  selectedFormat === format.id
                    ? "border-[var(--gold)] bg-[var(--gold)]/5"
                    : "border-[var(--gold)]/20 hover:border-[var(--gold)]/50"
                } ${format.premium ? "relative" : ""}`}
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                    selectedFormat === format.id
                      ? "bg-gradient-to-br from-[var(--gold)] to-[var(--gold-dark)]"
                      : "bg-[var(--gold)]/10"
                  }`}>
                    <format.icon className={`w-6 h-6 ${
                      selectedFormat === format.id ? "text-white" : "text-[var(--gold)]"
                    }`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-foreground">{format.name}</p>
                      {format.premium && (
                        <span className="px-2 py-0.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-medium rounded-full">
                          Premium
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-foreground/60">
                      {format.quality} • {format.size}
                    </p>
                  </div>
                </div>
                <input
                  type="radio"
                  name="format"
                  value={format.id}
                  checked={selectedFormat === format.id}
                  onChange={(e) => setSelectedFormat(e.target.value)}
                  className="w-5 h-5 accent-[var(--gold)]"
                  disabled={format.premium}
                />
              </label>
            ))}
          </div>
        </motion.div>

        {/* Download Options */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl p-8 border-2 border-[var(--gold)]/20 mb-6"
        >
          <h2 className="text-2xl font-heading font-semibold mb-6">What's Included</h2>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                <Check className="w-5 h-5 text-green-600" />
              </div>
              <span className="text-foreground/70">HD quality (1080p)</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                <Check className="w-5 h-5 text-green-600" />
              </div>
              <span className="text-foreground/70">Optimized for WhatsApp sharing</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                <Check className="w-5 h-5 text-green-600" />
              </div>
              <span className="text-foreground/70">Unlimited downloads</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center">
                <span className="text-yellow-600 text-sm">⚠</span>
              </div>
              <span className="text-foreground/70">Watermark included (upgrade to remove)</span>
            </div>
          </div>
        </motion.div>

        {/* Download Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <button
            onClick={handleDownload}
            disabled={formats.find(f => f.id === selectedFormat)?.premium}
            className="flex-1 px-8 py-5 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-xl hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all flex items-center justify-center gap-3 font-medium text-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <DownloadIcon className="w-6 h-6" />
            Download Now
          </button>
          <button
            onClick={() => navigate('/pricing')}
            className="px-8 py-5 bg-white border-2 border-[var(--gold)] text-foreground rounded-xl hover:bg-[var(--gold)]/5 transition-all flex items-center justify-center gap-2 font-medium"
          >
            Upgrade to Premium
          </button>
        </motion.div>

        {/* Premium CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8 bg-gradient-to-br from-[var(--gold-light)] to-[var(--cream-dark)] rounded-2xl p-8 border-2 border-[var(--gold)]/30"
        >
          <div className="text-center">
            <h3 className="text-2xl font-heading font-semibold text-foreground mb-3">
              Want watermark-free downloads?
            </h3>
            <p className="text-foreground/70 mb-6">
              Upgrade to our Basic plan for just ₹49 per invitation to remove watermarks and unlock premium features
            </p>
            <button
              onClick={() => navigate('/pricing')}
              className="px-8 py-4 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-xl hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all font-medium"
            >
              View Pricing Plans
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
