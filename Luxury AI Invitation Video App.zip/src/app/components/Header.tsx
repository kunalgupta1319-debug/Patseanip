import { Link, useNavigate } from "react-router-dom";
import { Sparkles, Menu, X, User, LogOut } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Will be connected to auth later
  const navigate = useNavigate();

  const handleLogout = () => {
    setIsLoggedIn(false);
    navigate("/");
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[var(--gold)]/20 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-[var(--gold)] to-[var(--gold-dark)] rounded-lg flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="font-heading text-2xl font-semibold bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] bg-clip-text text-transparent">
              ShaadiCards
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link to="/categories" className="text-foreground/80 hover:text-[var(--gold)] transition-colors">
              Categories
            </Link>
            <Link to="/templates" className="text-foreground/80 hover:text-[var(--gold)] transition-colors">
              Templates
            </Link>
            <Link to="/pricing" className="text-foreground/80 hover:text-[var(--gold)] transition-colors">
              Pricing
            </Link>
            {isLoggedIn ? (
              <>
                <Link to="/dashboard" className="text-foreground/80 hover:text-[var(--gold)] transition-colors flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Dashboard
                </Link>
                <button
                  onClick={handleLogout}
                  className="text-foreground/80 hover:text-destructive transition-colors flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-foreground/80 hover:text-[var(--gold)] transition-colors">
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="px-6 py-2.5 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-lg hover:shadow-lg hover:shadow-[var(--gold)]/30 transition-all"
                >
                  Get Started
                </Link>
              </>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-[var(--gold)]/20 space-y-3">
            <Link to="/categories" className="block py-2 text-foreground/80 hover:text-[var(--gold)] transition-colors">
              Categories
            </Link>
            <Link to="/templates" className="block py-2 text-foreground/80 hover:text-[var(--gold)] transition-colors">
              Templates
            </Link>
            <Link to="/pricing" className="block py-2 text-foreground/80 hover:text-[var(--gold)] transition-colors">
              Pricing
            </Link>
            {isLoggedIn ? (
              <>
                <Link to="/dashboard" className="block py-2 text-foreground/80 hover:text-[var(--gold)] transition-colors">
                  Dashboard
                </Link>
                <button
                  onClick={handleLogout}
                  className="block w-full text-left py-2 text-foreground/80 hover:text-destructive transition-colors"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="block py-2 text-foreground/80 hover:text-[var(--gold)] transition-colors">
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="block px-6 py-2.5 bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] text-white rounded-lg text-center"
                >
                  Get Started
                </Link>
              </>
            )}
          </nav>
        )}
      </div>
    </header>
  );
}
