import { Link } from "react-router-dom";
import { Sparkles, Facebook, Instagram, Twitter, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gradient-to-b from-background to-[var(--cream-dark)] border-t border-[var(--gold)]/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-[var(--gold)] to-[var(--gold-dark)] rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="font-heading text-2xl font-semibold bg-gradient-to-r from-[var(--gold)] to-[var(--gold-dark)] bg-clip-text text-transparent">
                ShaadiCards
              </span>
            </Link>
            <p className="text-sm text-foreground/60">
              Create stunning AI-powered invitation videos for your special moments
            </p>
          </div>

          <div>
            <h3 className="font-heading text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/categories" className="text-sm text-foreground/60 hover:text-[var(--gold)] transition-colors">Categories</Link></li>
              <li><Link to="/templates" className="text-sm text-foreground/60 hover:text-[var(--gold)] transition-colors">Templates</Link></li>
              <li><Link to="/pricing" className="text-sm text-foreground/60 hover:text-[var(--gold)] transition-colors">Pricing</Link></li>
              <li><Link to="/dashboard" className="text-sm text-foreground/60 hover:text-[var(--gold)] transition-colors">Dashboard</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading text-lg mb-4">Categories</h3>
            <ul className="space-y-2">
              <li><Link to="/templates/wedding" className="text-sm text-foreground/60 hover:text-[var(--gold)] transition-colors">Wedding</Link></li>
              <li><Link to="/templates/engagement" className="text-sm text-foreground/60 hover:text-[var(--gold)] transition-colors">Engagement</Link></li>
              <li><Link to="/templates/mehendi" className="text-sm text-foreground/60 hover:text-[var(--gold)] transition-colors">Mehendi</Link></li>
              <li><Link to="/templates/birthday" className="text-sm text-foreground/60 hover:text-[var(--gold)] transition-colors">Birthday</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading text-lg mb-4">Connect</h3>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-[var(--gold)]/10 hover:bg-[var(--gold)]/20 flex items-center justify-center transition-colors">
                <Facebook className="w-5 h-5 text-[var(--gold)]" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-[var(--gold)]/10 hover:bg-[var(--gold)]/20 flex items-center justify-center transition-colors">
                <Instagram className="w-5 h-5 text-[var(--gold)]" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-[var(--gold)]/10 hover:bg-[var(--gold)]/20 flex items-center justify-center transition-colors">
                <Twitter className="w-5 h-5 text-[var(--gold)]" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-[var(--gold)]/10 hover:bg-[var(--gold)]/20 flex items-center justify-center transition-colors">
                <Mail className="w-5 h-5 text-[var(--gold)]" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-[var(--gold)]/20 text-center text-sm text-foreground/60">
          <p>&copy; 2026 ShaadiCards. All rights reserved. Crafted with love for your special moments.</p>
        </div>
      </div>
    </footer>
  );
}
