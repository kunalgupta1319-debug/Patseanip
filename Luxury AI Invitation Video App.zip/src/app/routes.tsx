import { createBrowserRouter } from "react-router-dom";
import RootLayout from "./layouts/RootLayout";
import Home from "./pages/Home";
import Categories from "./pages/Categories";
import Templates from "./pages/Templates";
import Editor from "./pages/Editor";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Pricing from "./pages/Pricing";
import Preview from "./pages/Preview";
import Download from "./pages/Download";
import NotFound from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: Home },
      { path: "categories", Component: Categories },
      { path: "templates/:category?", Component: Templates },
      { path: "editor/:templateId?", Component: Editor },
      { path: "login", Component: Login },
      { path: "signup", Component: Signup },
      { path: "dashboard", Component: Dashboard },
      { path: "pricing", Component: Pricing },
      { path: "preview/:invitationId", Component: Preview },
      { path: "download/:invitationId", Component: Download },
      { path: "*", Component: NotFound },
    ],
  },
]);
