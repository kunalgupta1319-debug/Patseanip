
  # Luxury AI Invitation Video App

  This is a code bundle for Luxury AI Invitation Video App. The original project is available at https://www.figma.com/design/0Lav1LETkw7eSDNcu8Gm9Y/Luxury-AI-Invitation-Video-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  